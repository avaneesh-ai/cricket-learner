import { defineConfig } from "vite";

export default defineConfig({
  appType: "spa",
  publicDir: "public",
  server: {
    host: "0.0.0.0",
    port: 4173,
  },
  preview: {
    host: "0.0.0.0",
    port: 4173,
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
